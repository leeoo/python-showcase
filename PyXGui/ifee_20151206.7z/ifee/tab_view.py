__author__ = 'leeoo'


from PyQt5.QtWidgets import *


class TabView(QWidget):

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        pass