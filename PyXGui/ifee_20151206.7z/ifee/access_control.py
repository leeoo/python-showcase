#!/bin/python
# -*- coding: utf-8 -*-
################################################################################
# author: Lex Li
# version: 1.0
################################################################################

# TODO


class Resource:
    pass


class Authority:
    pass


class Role:
    pass


class Group:
    pass


class User:
    pass