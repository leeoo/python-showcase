
DROP DATABASE IF EXISTS ifee;

CREATE DATABASE ifee;


CREATE TABLE account(
    account_id SERIAL,
    version INTEGER,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    salt VARCHAR(255),
    password_hint VARCHAR(50),
    gender VARCHAR(20),
    age INTEGER,
    phone_number VARCHAR(50),
    email VARCHAR(50),
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    account_enabled BOOLEAN,
    account_locked BOOLEAN,
    account_expired BOOLEAN,
    credentials_expired BOOLEAN,
    PRIMARY KEY (account_id)
);

CREATE TABLE portfolio(
    portfolio_id SERIAL,
    version INTEGER,
    portfolio_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (portfolio_id)
);

CREATE TABLE facility(
    facility_id SERIAL,
    version INTEGER,
    facility_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (facility_id)
);

CREATE TABLE portfolio_position(
    position_id SERIAL,
    version INTEGER,
    position_name VARCHAR(50) NOT NULL UNIQUE,
    commitment_amount NUMERIC(25, 2),
    portfolio_id SERIAL,
    facility_id SERIAL,
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (position_id)
);

-- 收入
CREATE TABLE income(
    income_id SERIAL,
    version INTEGER,
    name VARCHAR(50) NOT NULL,
    amount NUMERIC(25, 2),
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (income_id)
);

-- 支出
CREATE TABLE payment(
    payment_id SERIAL,
    version INTEGER,
    name VARCHAR(50) NOT NULL,
    amount NUMERIC(25, 2),
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (payment_id)
);

-- 报销
CREATE TABLE bao_xiao(
    bao_xiao_id SERIAL,
    version INTEGER,
    name VARCHAR(50) NOT NULL,
    amount NUMERIC(25, 2),
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (bao_xiao_id)
);

-- 余额宝
CREATE TABLE yu_e_bao(
    yu_e_bao_id SERIAL,
    version INTEGER,
    name VARCHAR(50) NOT NULL,
    amount NUMERIC(25, 2),
    description VARCHAR(255),
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (yu_e_bao_id)
);

CREATE TABLE book(
    book_id SERIAL,
    version INTEGER,
    book_chinese_name VARCHAR(50),
    book_english_name VARCHAR(50),
    author_chinese_name VARCHAR(100),
    author_english_name VARCHAR(100),
    book_type VARCHAR(20), -- 书籍载体介质种类：如纸质、Mobi、ePub、PDF和TXT等
    book_class VARCHAR(30), -- 书籍分类：如人文社科、自然科学、IT等
    description VARCHAR(255),
    reading_status VARCHAR(30), -- 阅读状态：未开始、想要阅读、正在阅读、已读等
    creator VARCHAR(50),
    modifier VARCHAR(50),
    creation_time TIMESTAMP,
    modification_time TIMESTAMP,
    PRIMARY KEY (book_id)
);


CREATE TABLE todo(
    todo_id SERIAL,
    version INTEGER,
    flag CHAR(1), -- T/F or Y/N or 1/0 or V/X
    add_or_reduce CHAR(1), -- +/-
    content VARCHAR(255),
    creator VARCHAR(50),
    creation_time TIMESTAMP,
    modifier VARCHAR(50),
    modification_time TIMESTAMP,
    PRIMARY KEY (todo_id)
);
