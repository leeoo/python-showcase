"""
@author: Lex
@version: 1.0, 2014/7/12
"""
oi


class Fee():

    def __init__(self):
        self.feeId = None
        self.name = None
        self.type = None
        self.amount = None
        self.comment = None

