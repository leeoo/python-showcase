__author__ = 'leeoo'


import logging
from logging import Logger, StreamHandler, FileHandler


class Log4P():

    def __init__(self):
        self.log = Logger('Log4P', logging.DEBUG)
        self.log.addHandler(StreamHandler())
        self.log.addHandler(FileHandler('../ifee.log'))

    def show_log(self):
        self.log.debug('The showLog method that call Logger.info method!')


def main():
    log = Log4P()
    log.show_log()


if __name__ == '__main__':
    main()
