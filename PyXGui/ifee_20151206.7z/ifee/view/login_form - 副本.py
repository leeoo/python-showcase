# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'G:\workshop\Python\PyQt\ifee\view\loginForm.ui'
#
# Created: Sat Feb 15 19:40:46 2014
#      by: PyQt5 UI code generator 5.1.1
#
# WARNING! All changes made in this file will be lost!

